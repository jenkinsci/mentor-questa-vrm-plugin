consData = [[1]];
processConsData(consData);
